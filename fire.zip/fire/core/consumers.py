
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.generic.websocket import WebsocketConsumer
from asgiref.sync import async_to_sync,sync_to_async
import json
from .models import *
import asyncio
from core.models import *
import time
from http import client
import paho.mqtt.client as paho
import sys
from channels.layers import get_channel_layer
from base64 import decode
# import pymysql
import time
from threading import Thread
import pickle
from threading import Thread


# pickled_model1 = pickle.load(open('fire-connect_version1.pkl', 'rb'))
# Create your views here.


# async def home1(group,msg):
#     channel_layer=get_channel_layer()
#     await (channel_layer.group_send)(group,{'type':"send_order",'value':json.dumps(msg)})




# def prediction(topic,msg):
#     pass
    # print("topic:",topic,"msg:",msg)
    # str2 = msg.split(',') 
    # a=[]
    # # print(str2)
    # a.append(int(str2[0]))
    # a.append(int(str2[1]))
    # a.append(int(str2[2]))
    # a.append(int(str2[3]))
    # a.append(int(str2[4]))
    # # pred=pickled_model1.predict([a])
    # print("machine name:",topic,"condition:",pred)
    # str2.clear()
    # a.clear()
    # print(a)
    # print(str2)
    
# def disp(i):
#         def onMessage(clinet,userdata,msg):
#             print(msg.topic+": "+ msg.payload.decode())
#             print(type(msg.payload.decode()))
#             a=msg.topic
#             s=msg.payload.decode()
#             asyncio.run(home1(a,s))
#             # prediction(a,s)
#             # if a=='a3':
#             #     sahil.append(s)
#             # print(sahil)
#             # print(pickled_model.predict([s]))

#         client=paho.Client()
#         client.on_message=onMessage

#         if client.connect("localhost",1883,60)!=0:
#             print("could not connect to MQTT broker!")
#             sys.exit(-1)
#         client.subscribe(i)

#         try:
#             print("press CTRL+C to exit....")
#             client.loop_forever()

#         except:
#             print("Disconnecting from broker...")
#             client.disconnect()
#             time.sleep(1)

#Start all threads. 
# threads = []

# machine=Machine.objects.all()
# stop_machine=Stop_machine.objects.all()
# stop_m=[]

# for name in stop_machine:
#     stop_m.append(name.machine)
    
    
# all_machine=[]
# for e in machine.machine_ID:
#     all_machine.append(e)



# student_list = Machine.objects.all()
# for student in student_list:
#     all_machine.append(student.machine_ID)
#     # print(student.machine_ID)

# print("all runing machine",all_machine)
# print("all stoping machine machine",stop_m)


# if stop_m:
#     for stop in stop_m:
#         for start in all_machine:
#             if stop==start:
#                 pass
#             else:
#                 t = Thread(target=disp, args=(start,))
#                 t.start()
#                 threads.append(t)
# else:
#     for n in all_machine:
#         t = Thread(target=disp, args=(n,))
#         t.start()
#         threads.append(t)
                  
        
# a=['ABC','ABCD','ABCDE','ABCDEF','a1','a2','a3']
# for n in all_machine:
#     t = Thread(target=disp, args=(n,))
#     t.start()
#     threads.append(t)








class OrderConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        print("Websocket connect....")
        print("channel Layer",self.channel_layer)
        print("channel Name",self.channel_name)
        self.group_name = self.scope['url_route']['kwargs']['groupname']
        print("group Name:",self.group_name)
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        await self.accept()
        # self.group_name='order_data'
        # await self.channel_layer.group_add(
        #     self.group_name,
        #     self.channel_name
        # )

        # await self.accept()

    async def disconnect(self,close_code):
        pass

    async def receive(self,text_data):
        print (text_data)
        await self.channel_layer.group_send(
            self.group_name,
            {
                'type':'send_order',
                'value':text_data,
            }
        )

    async def send_order(self,event):
        print ("this is event",event['value'])
        await self.send(event['value'])

        




































# from channels.generic.websocket import AsyncWebsocketConsumer
# import json
# from random import randint
# from asyncio import sleep
# import paho.mqtt.client as paho
# from django.shortcuts import render
# import time
# from django.contrib.auth.models import User

# # import time

# # tem=[]
# # noise=[]
# # x=[]
# # y=[]
# # z=[]
# # sa=[]
# # topic=[]
# # sub_topic=[]



# def mname(request,my_id):
# #     topic.append(my_id)
# #     print("curnt to pic",my_id)

   
# #     def onMessage(clinet,userdata,msg):
# #         a=msg.topic
# #         sub_topic.append(a)
# #         s=msg.payload.decode()
# #         print("to",topic)
# #         print("current",a)
# #         if a==topic[-1]:
# #             pass
# #         else:
# #             client.disconnect()
            
# #         # print("current topic",msg.topic)
# #         # print("cureent ID",my_id)
# #         # client.unsubscribe("ABCD")
# #         sa.append(s)
# #         saa=sa[0]
# #         str2 = saa.split(',') 
# #         tem.append(str2[0])
# #         noise.append(str2[1])
# #         x.append(str2[2])
# #         y.append(str2[3])
# #         z.append(str2[4])
# #         # client.disconnect()

 
#     # client=paho.Client()
#     # client.connect("localhost",1883,60)
#     # client.subscribe(my_id)
   
#     # client.on_message=onMessage
#     # client.loop_start()
    
#     # def dis():
#     #     print("diconnect fucntion has been called")
#     #     client.unsubscribe("ABCD")
#     #     client.disconnect()
#     # client.disconnect()
#     # # client.loop_write()
#     # print(topic)
#     # if len(topic)>=1:
#     #     if len(sub_topic)>=1:
#     #         if topic[-1]!=sub_topic[0]:
#     #             print("disconnect")
#     #             dis()
#     #             # # client=paho.Client()
#     #             # # client.connect("localhost",1883,60)
#     #             # # client.loop_start()
#     #             # client.disconnect()
#     #             # client.loop_stop()
#     #             # client.disconnect()
#     #             # client.loop_stop()
#     #     else:
#     #         print("there is no value in sub_topic")    
            
#     # # client.disconnect()
#     # current=request.user
#     # id=current.id
#     # user=User.objects.get(id=id)
#     # all_ma=user.machine_set.all()
#     # for i in all_ma:
#     #     print("machine name",i.machine_ID)
#     # all_user=User.objects.all()
#     # print("current user",user)
#     # print("all user",all_user)
#     # print("all machines",all_ma)
#     # print("this si currunt topic",my_id)
#     # conext={'machine':all_ma,'user':user}
    
    
#     return render(request,'machine.html')


    

# # def onMessage(clinet,userdata,msg):

# #     s=msg.payload.decode()
# #     sa.append(s)
# #     print
# #     saa=sa[0]
# #     str2 = saa.split(',') 
# #     tem.append(str2[0])
# #     noise.append(str2[1])
# #     x.append(str2[2])
# #     y.append(str2[3])
# #     z.append(str2[4])
    

# # #     # tem.append(a[1:3])
# # #     # noise.append(a[5:9])
# # #     # x.append(a[11:14])
# # #     # y.append(a[16:19])
# # #     # z.append(a[21:24])



# # client=paho.Client()
# # client.on_message=onMessage
# # client.connect("localhost",1883,60)
# # client.subscribe("test/status")
# # client.loop_start()
# # client.subscribe("test/status")



# # def executeSomething():
# #     sa.clear()
# #     tem.clear()
# #     noise.clear()
# #     x.clear()
# #     y.clear()
# #     z.clear()
# #     # topic.clear()
# #     sub_topic.clear()
# #     time.sleep(1)






# # if len(sa)>=1:
# #     # saa=sa[0]
# #     # str2 = saa.split(',') 

# #     noise.append(str2[1])
# #     x.append(str2[2])
# #     y.append(str2[3])
# #     z.append(str2[4])




# class GraphConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         # await self.send(json.dumps({'value':randint(2000,2500)}))
#         # for i in range(1000):
#         # global onMessage
#         while True:
#             await self.send(json.dumps({'value':randint(80,100)}))
#             await sleep(1)
#         #     if len(tem)>=1:
#         #         print(tem)
#         #         print("topic",topic)
#         #         print("this is sub",sub_topic)
#         #         await self.send(json.dumps({'value':tem[0]}))
#         #         await sleep(1)
#         #         # tem.clear()
#         #         executeSomething() 
#         #         # sleep(1) 
#         #     else:
#         #         await sleep(1)
#         #         # sleep(1)
            
#     # print(sa)
#             # await self.send(json.dumps({'value':randint(2000,2500)}))
#             #     await self.send(json.dumps({'value':tem[-1]}))
#             #     await sleep(1) 
#             # sleep(1)      
#         # while True:
#         #     # print(sa)
#         #     # for i in range(1000):
#         #     if len(sa)>=1:
#         #         data=sa
#         #         saa=data[0]
#         #         str2 = saa.split(',')
#         #         print("this is sa",sa)
#         #         await self.send(json.dumps({'value':str2[0]}))
#         #         str2.clear()
#         #         sa.clear()
#         #         await sleep(1)
#         #     else:
#         #         pass

#         #     # break
#         #     time.sleep(1)
            
            
# class GraphConsumer1(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         await self.send(json.dumps({'value':randint(2000,2500)}))
#         # await self.accept()

#         # # for i in range(1000):
#         while True:
#             await self.send(json.dumps({'value':randint(2000,2500)}))
#             await sleep(1)
#         #     if len(noise)>=1:
#         #         await self.send(json.dumps({'value':noise[0]}))
#         #         await sleep(1) 
#         #         # noise.clear()
#         #     else:
#         #         await sleep(1)

#             # sleep(1)      
        
#         # while True:
#         #     # print(sa)
#         #     # for i in range(1000):
#         #     if len(sa)>=1:
#         #         data=sa
#         #         saa=data[0]
#         #         str2 = saa.split(',')
#         #         print("this is sa",sa)
#         #         await self.send(json.dumps({'value':str2[1]}))
#         #         str2.clear()
#         #         sa.clear()
#         #         await sleep(1)
#         #     else:
#         #         pass

#         #     # break
#         #     time.sleep(1)


# class GraphConsumer2(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
        
#         # await self.accept()
#         # # for i in range(1000):
#         while True:
#             await self.send(json.dumps({'value':randint(2000,2500)}))
#             await sleep(1)
#         #     if len(x)>=1:
#         #         await self.send(json.dumps({'value':x[0]}))
#         #         await sleep(1)
#         #     else:
#         #         await sleep(1)

#             # sleep(1)
        
#         # while True:
#         #     # print(sa)
#         #     # for i in range(1000):
#         #     if len(sa)>=1:
#         #         data=sa
#         #         saa=data[0]
#         #         str2 = saa.split(',')
#         #         print("this is sa",sa)
#         #         await self.send(json.dumps({'value':str2[2]}))
#         #         str2.clear()
#         #         sa.clear()
#         #         await sleep(1)
#         #     else:
#         #         pass

#         #     # break
#         #     time.sleep(1)

# class GraphConsumer3(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         while True:
#             await self.send(json.dumps({'value':randint(2000,2500)}))
#             await sleep(1)
#         # await self.accept()
#         # # for i in range(1000):
#         # while True:
#         #     if len(y)>=1:
#         #         await self.send(json.dumps({'value':y[0]}))
#         #         await sleep(1)
#         #         # sleep(1)
#         #     else:
#         #         await sleep(1)
        
#         # while True:
#         #     # print(sa)
#         #     # for i in range(1000):
#         #     if len(sa)>=1:
#         #         data=sa
#         #         saa=data[0]
#         #         str2 = saa.split(',')
#         #         print("this is sa",sa)
#         #         await self.send(json.dumps({'value':str2[3]}))
#         #         str2.clear()
#         #         sa.clear()
#         #         await sleep(1)
#         #     else:
#         #         pass

#         #     # break

#         #     time.sleep(1)
            
# class GraphConsumer4(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         # await self.send(json.dumps({'value':randint(2000,2500)}))
#         while True:
#             await self.send(json.dumps({'value':randint(2000,2500)}))
#             await sleep(1)
        #     if len(z):
        #         await self.send(json.dumps({'value':z[0]}))
        #         await sleep(1)
        #     else:
        #         await sleep(1)
            # time.sleep(1)
        # for i in range(1000):
    # async def onMessage(self,clinet,userdata,msg):
    #             s=msg.payload.decode()
    #             print(msg.topic+": "+ msg.payload.decode())
    #             await self.send(json.dumps({'value':s}))
    # client=paho.Client()
    # client.on_message=onMessage

    # client.connect("localhost",1883,60)
    # client.subscribe("test/status")
    # client.loop_start()
    # client.subscribe("test/status")
   
        # while True:
        #     # print(sa)
        #     # for i in range(1000):
        #     if len(sa)>=1:
        #         data=sa
        #         saa=data[0]
        #         str2 = saa.split(',')
        #         print("this is sa",sa)
        #         await self.send(json.dumps({'value':str2[4]}))
        #         str2.clear()
        #         sa.clear()
        #         await sleep(1)
        #     else:
        #         pass

            # break

            # time.sleep(1)

# while True:
#     time.sleep(1)
#     data=sa
#     class GraphConsumer(AsyncWebsocketConsumer):
#         async def connect(self):
#             await self.accept()
#             while True:
#                 if len(data)>=1:
#                     print(data)
                    
#                     saa=data[0]
#                     str2 = saa.split(',')  
#                     await self.send(json.dumps({'value':int(str2[0])}))
#                     sa.clear()
#                     str2.clear()
#                     # await asyncio.sleep(1)
#                 else:
#                     pass

#     class GraphConsumer1(AsyncWebsocketConsumer):
#         async def connect(self):
#             await self.accept()
#             while True:
#                 if len(data)>=1:
#                     print(data)
                    
#                     saa=data[0]
#                     str2 = saa.split(',')  
#                     await self.send(json.dumps({'value':int(str2[1])}))
#                     sa.clear()
#                     str2.clear()
#                     # await asyncio.sleep(1)
#                 else:
#                     pass

#     class GraphConsumer2(AsyncWebsocketConsumer):
#         async def connect(self):
#             await self.accept()
#             while True:
#                 if len(data)>=1:
#                     print(data)
                    
#                     saa=data[0]
#                     str2 = saa.split(',')  
#                     await self.send(json.dumps({'value':int(str2[2])}))
#                     sa.clear()
#                     str2.clear()
#                     # await asyncio.sleep(1)
#                 else:
#                     pass
#     class GraphConsumer3(AsyncWebsocketConsumer):
#         async def connect(self):
#             await self.accept()
#             while True:
#                 if len(data)>=1:
#                     print(data)
                    
#                     saa=data[0]
#                     str2 = saa.split(',')  
#                     await self.send(json.dumps({'value':int(str2[3])}))
#                     sa.clear()
#                     str2.clear()
#                     # await asyncio.sleep(1)
#                 else:
#                     pass
#     class GraphConsumer4(AsyncWebsocketConsumer):
#         async def connect(self):
#             await self.accept()
#             while True:
#                 if len(data)>=1:
#                     print(data)
                    
#                     saa=data[0]
#                     str2 = saa.split(',')  
#                     await self.send(json.dumps({'value':int(str2[4])}))
#                     sa.clear()
#                     str2.clear()
#                     # await asyncio.sleep(1)
#                 else:
#                     pass
#     break




# for i in range(3):
#     time.sleep(10)
#     client=paho.Client()
#     client.connect("localhost",1883,60)
#     client.subscribe(m[0])
   
#     # client.on_message=onMessage
#     client.loop_start()
#     client.disconnect()