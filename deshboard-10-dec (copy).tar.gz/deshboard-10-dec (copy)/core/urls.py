from atexit import register
from django.contrib import admin
from django.urls import path
from core import views, views1
from core import consumers
from django.urls import path, re_path

urlpatterns = [
	# path('register/', views.registerPage, name="register"),
	# path('login/', views.loginPage, name="login"),  
	# path('logout/', views.logoutUser, name="logout"),


    path("", views.index, name='home1'),
    path("about/", views.about, name='about'),
    path("services/", views.services, name='services'),
    path("services1/", views.services1, name='services1'),
    path("machine/<str:group_name>/", views.machine, name='machine'),
   
    path("header/",views.header, name='header'),
    path("login1/",views.login, name='login1'),
    path("log1/",views.log, name='log1'),
    path('register/',views.register,name="register"),
    path('login_user/',views.login_user,name="login_user"),
    path('services1/logout_user/',views.logout_user,name="logout_user"),
    path('new_machine/',views.new_machine,name="new_machine"),
    path('plot/',views.test,name="plot"),
    path('plot/',views.test,name="plot"),
    path('sensor/',views1.sensor,name="sensor"),
    path('stop/<str:group_name>/',views1.stop,name="stop"),
    path('start/<str:group_name>/',views1.start,name="start"),
    path('delete/<str:group_name>/',views1.delete,name="delete"),
    path("base/",views.base,name="base"),
    path("base1/",views1.newd,name="base1"),
    path("base11/",views1.newd1,name="base11"),
    path("test/",views1.test,name="test"),
    # path("data/<my_id>/",consumers.mname,name="mname"),
    path("emails/",views1.email1,name="email"),
    path("fault/",views1.fault,name="fault"),
    path("fault_P/",views1.fault_P,name="fault_P"),
    path("fault_F/",views1.future_fault,name="fault_F"),
    
    
    
    
    
    path("delete_submit/<str:group_name>/",views1.delete_submit,name="delete_submit"),
    path("stop_submit/<str:group_name>/",views1.stop_submit,name="stop_submit"),
    path("start_submit/<str:group_name>/",views1.start_submit,name="start_submit"),
    
    path('future_prediction_chart/',views1.future_prediction_chart,name="future_prediction_chart")
    
   
    
]
    
