from django.contrib import admin

# Register your models here.

from .models import *

admin.site.register(Machine)
# from .forms import *

# admin.site.register(CreateUserForm)

admin.site.register(Fault_occur)

admin.site.register(Fault_future)
admin.site.register(Email_user)
admin.site.register(Stop_machine)
