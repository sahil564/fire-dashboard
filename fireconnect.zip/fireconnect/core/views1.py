from multiprocessing import context
from django.shortcuts import render, HttpResponse
from django.shortcuts import render, redirect 
from django.contrib.auth.models import User
from core.models import *
from core.models import Stop_machine as Stop
# Create your views here.

def sensor(request):
    return render(request, 'base.html')
    # return HttpResponse("this is homepage")
    
def stop(request,group_name):
    print("stop_fuction",group_name)
    return render(request,"stop.html",{"groupname":group_name})


def stop_submit(request,group_name):
    print(group_name)
    if Stop.objects.filter(machine = group_name).exists():
        print("already exists")
    # at least one object satisfying query exists
    else:
        user=Stop(machine=group_name)
        user.save()
    # Machine.objects.get(machine_ID=group_name).delete()
    return redirect('services1')

def stop(request,group_name):
    print("stop_fuction",group_name)
    return render(request,"stop.html",{"groupname":group_name})



def start(request,group_name):
    print("start_fuction",group_name)
    return render(request,"start.html",{"groupname":group_name})

def start_submit(request,group_name):
    print("this is submit start",group_name)
    Stop.objects.get(machine=group_name).delete()
    # return render(request,"start.html",{"groupname":group_name})
    return redirect('services1')








def delete(request,group_name):
    print(group_name)
    # Machine.objects.get(machine_ID=group_name).delete()
    return render(request,"Mdelete.html",{"groupname":group_name})

def delete_submit(request,group_name):
    print(group_name)
    Machine.objects.get(machine_ID=group_name).delete()
    return redirect('services1')












def newd(request):

    return render(request,'bar.html')
    



def newd1(request):
    return render(request,'future.html')

def test(request):
    return render(request,'newcheck.html')

def email1(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.email_user_set.all()
    fault_N=user.email_user_set.count()
    all_user=User.objects.all()
    
    print("current user",user)
    print("all user",all_user)
    print("all user",fault)
 
    conext={'faults':fault,'user':user,'Number_fault':fault_N}
    return render(request,"EMAIL.html",conext)

 
 
 
 
 
 
 
 
 
def fault(request):

    return render(request,"fault.html") 
    
def fault_P(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.fault_occur_set.all()
    all_user=User.objects.all()
    
    print("current user",user)
    print("all user",all_user)
    print("all user",fault)
 
    conext={'faults':fault}
    return render(request,"fault1.html",conext)
    

def future_fault(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.fault_future_set.all()
    all_user=User.objects.all()
    
    print("future current user",user)
    print(" future all user",all_user)
    print(" future all user",fault)
 
    conext={'faults':fault}
    return render(request,"fault2.html",conext)


def machine_delete(request,machine_name):
    Machine.objects.get(machine_ID=machine_name).delete()
    
    
    
    
    
def future_prediction_chart(request):
    return render(request,'futureForcating.html')